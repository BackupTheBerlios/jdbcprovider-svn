/* 
    JSPWiki - a JSP-based WikiWiki clone.

    Copyright (C) 2004-2005 Xan Gregg (xan.gregg@forthgo.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation; either version 2.1 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.forthgo.jspwiki.jdbcprovider;

import com.ecyrd.jspwiki.*;
import com.ecyrd.jspwiki.attachment.Attachment;
import com.ecyrd.jspwiki.attachment.AttachmentManager;
import com.ecyrd.jspwiki.providers.ProviderException;
import com.ecyrd.jspwiki.providers.WikiAttachmentProvider;
import com.ecyrd.jspwiki.util.ClassUtil;
import org.apache.log4j.Category;

import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.Date;

/*
 * History:
 *   2006-02-10    Added an extra column to the database containing the attachment size,
 *                 as SyBase cannot determin the size of a blob from SQL.
 *                 Also made sure, that when migrating the attachment orignal date is preserved.
 *   2005-09-28 XG Use jspwiki-s as property prefix for security.
 *   2005-09-07 XG Always use java.util.Date for LastModifield field to friendlier comparisons.
 */

/**
 * Provides a database-based repository for Wiki attachments.
 * MySQL commands to create the tables are provided in the code comments.
 * <p/>
 * Based on Thierry Lach's DatabaseProvider, which supported Wiki pages
 * but not attachments.
 * 
 * @author Thierry Lach
 * @author Xan Gregg
 * @see JDBCPageProvider
 */
public class JDBCAttachmentProvider extends JDBCBaseProvider
        implements WikiAttachmentProvider
{

/* MySQLtable creation commands:
CREATE TABLE WIKI_ATT
    (
        ATT_PAGENAME      VARCHAR (100)  NOT NULL,
        ATT_FILENAME      VARCHAR (100)  NOT NULL,
        ATT_VERSION       INTEGER        NOT NULL,
        ATT_MODIFIED      DATETIME,
        ATT_MODIFIED_BY   VARCHAR (50),
        ATT_DATA          MEDIUMBLOB,
        PRIMARY KEY (ATT_PAGENAME, ATT_FILENAME, ATT_VERSION),
        UNIQUE (ATT_PAGENAME, ATT_FILENAME, ATT_VERSION),
        INDEX ATT_MODIFIED_IX (ATT_MODIFIED)
    );
*/

    private static final String ATT_TABLE_NAME = "WIKI_ATT";

    protected static final Category log = Category.getInstance( JDBCAttachmentProvider.class );

    private boolean m_migrating;
    
    public String getProviderInfo()
    {
        return "JDBC/MySQL attachment provider";
    }

    public void initialize(WikiEngine engine, Properties properties) throws NoRequiredPropertyException, IOException
    {
        debug( "Initializing JDBCAttachmentProvider" );
        super.initialize( engine, properties);
        try
        {
            checkTable( JDBCAttachmentProvider.ATT_TABLE_NAME );
        }
        catch( SQLException e )
        {
            throw new IOException( "SQL Exception: " + e.getMessage() );
        }
        int n = getAttachmentCount();
        String migrationPath = properties.getProperty( getPropertyBase() + "migrateFrom" );
        if( n == 0 && migrationPath != null )
            migratePages( engine, migrationPath );
    }

    protected String getPropertyBase()
    {
        return "jspwiki-s.JDBCAttachmentProvider.";  // -s prevents display as a wikii variable for security
    }

    public Category getLog()
    {
        return log;
    }

    public String getCheckAliveTableName() {
        return ATT_TABLE_NAME;
    }

    public int getAttachmentCount()
    {
        int count = 0;
        Connection connection = null;
        try
        {
            connection = getConnection();
            String sql = "SELECT COUNT(*) FROM " + ATT_TABLE_NAME;
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery( sql );
            rs.next();
            count = rs.getInt( 1 );
            rs.close();
            stmt.close();
        }
        catch( SQLException se )
        {
            error( "unable to get attachment count ", se );
        }
        finally
        {
            releaseConnection( connection );
        }
        return count;

    }

    // apparently version number and size should not be relied upon at this point
    public void putAttachmentData( Attachment att, InputStream dataStream )
            throws ProviderException, IOException
    {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        FileUtil.copyContents( dataStream, baos );
        byte data[] = baos.toByteArray();
        int version = findLatestVersion( att ) + 1;
        Connection connection = null;
        try
        {
            connection = getConnection();
            String sql = "INSERT INTO " + ATT_TABLE_NAME +
                    " (ATT_PAGENAME, ATT_FILENAME, ATT_VERSION," +
                    "  ATT_MODIFIED, ATT_MODIFIED_BY, ATT_DATA, ATT_LENGTH)" +
                    " VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement psPage = connection.prepareStatement( sql );
            psPage.setString( 1, att.getParentName() );
            psPage.setString( 2, att.getFileName() );
            psPage.setInt( 3, version );
            Timestamp d;
            if( m_migrating && att.getLastModified() != null )
            {
                d = new Timestamp( att.getLastModified().getTime() );
            }
            else
            {
                d = new Timestamp( System.currentTimeMillis() );
            }
            psPage.setTimestamp( 4, d );
            psPage.setString( 5, att.getAuthor() );
            psPage.setBytes( 6, data );
            psPage.setInt(7, data.length);
           
            psPage.execute();
            psPage.close();
        }
        catch( SQLException se )
        {
            error( "Saving attachment failed " + att, se );
        }
        finally
        {
            releaseConnection( connection );
        }
    }

    public InputStream getAttachmentData( Attachment att ) throws ProviderException, IOException
    {
        InputStream result = null;
        Connection connection = null;
        try
        {
            connection = getConnection();
            String sql = "SELECT ATT_DATA FROM " + ATT_TABLE_NAME +
                    " WHERE ATT_PAGENAME = ?" +
                    " AND ATT_FILENAME = ?" +
                    " AND ATT_VERSION = ?";
            PreparedStatement ps = connection.prepareStatement( sql );
            ps.setString( 1, att.getParentName() );
            ps.setString( 2, att.getFileName() );
            ps.setInt( 3, att.getVersion() );
            ResultSet rs = ps.executeQuery();

            if( rs.next() )
            {
                byte[] bytes = rs.getBytes( "ATT_DATA" );
                result = new ByteArrayInputStream( bytes );
                //result = rs.getBinaryStream("VERSION_TEXT");
            }
            else
            {
                error( "No attachments to read; '" + att + "'", new SQLException( "empty attachment set" ) );
            }
            rs.close();
            ps.close();

        }
        catch( SQLException se )
        {
            error( "Unable to read attachment '" + att + "'", se );
        }
        finally
        {
            releaseConnection( connection );
        }
        return result;
    }

    // latest versions only
    public Collection listAttachments( WikiPage page ) throws ProviderException
    {
        Collection result = new ArrayList();
        Connection connection = null;
        try
        {
            connection = getConnection();
            String sql = "SELECT ATT_LENGTH," +
                    " ATT_FILENAME, " +
                    " ATT_MODIFIED, ATT_MODIFIED_BY, ATT_VERSION" +
                    " FROM " + ATT_TABLE_NAME +
                    " WHERE ATT_PAGENAME = ?" +
                    " GROUP BY ATT_FILENAME" +
                    " ORDER BY ATT_VERSION DESC";   // so latest version is first
            PreparedStatement ps = connection.prepareStatement( sql );
            ps.setString( 1, page.getName() );
            ResultSet rs = ps.executeQuery();

            String previousFileName = "";
            while( rs.next() )
            {
                int size = rs.getInt( "ATT_LENGTH" );
                String fileName = rs.getString( "ATT_FILENAME" );
                if( fileName.equals( previousFileName ) )
                    continue;   // only add latest version
                Attachment att = new Attachment( getEngine(), page.getName(), fileName );
                att.setSize( size );
                // use Java Date for friendlier comparisons with other dates
                att.setLastModified(new java.util.Date(rs.getTimestamp("ATT_MODIFIED").getTime()));
                att.setAuthor( rs.getString( "ATT_MODIFIED_BY" ) );
                att.setVersion( rs.getInt( "ATT_VERSION" ) );
                result.add( att );
            }
            rs.close();
            ps.close();

        }
        catch( SQLException se )
        {
            error( "Unable to list attachments", se );
        }
        finally
        {
            releaseConnection( connection );
        }
        return result;
    }

    public Collection findAttachments( QueryItem[] query )
    {
        return new ArrayList(); // fixme
    }

    public List listAllChanged( Date timestamp ) throws ProviderException
    {
        List changedList = new ArrayList();

        Connection connection = null;
        try
        {
            connection = getConnection();
            String sql = "SELECT ATT_PAGENAME, ATT_FILENAME," +
                    " ATT_LENGTH," +
                    " ATT_MODIFIED, ATT_MODIFIED_BY, ATT_VERSION" +
                    " FROM " + ATT_TABLE_NAME +
                    " WHERE ATT_MODIFIED > ?" +
                    " ORDER BY ATT_MODIFIED DESC";
            PreparedStatement ps = connection.prepareStatement( sql );
            ps.setTimestamp( 1, new Timestamp( timestamp.getTime() ) );
            ResultSet rs = ps.executeQuery();
            while( rs.next() )
            {
                Attachment att = new Attachment( getEngine(), rs.getString( "ATT_PAGENAME" ), rs.getString( "ATT_FILENAME" ) );
                att.setSize( rs.getInt( "ATT_LENGTH" ) );
                // use Java Date for friendlier comparisons with other dates
                att.setLastModified(new java.util.Date(rs.getTimestamp("ATT_MODIFIED").getTime()));
                att.setAuthor( rs.getString( "ATT_MODIFIED_BY" ) );
                att.setVersion( rs.getInt( "ATT_VERSION" ) );
                changedList.add( att );
            }
            rs.close();
            ps.close();
        }
        catch( SQLException se )
        {
            error( "Error getting changed list, since " + timestamp, se );
        }
        finally
        {
            releaseConnection( connection );
        }

        return changedList;
    }

    public Attachment getAttachmentInfo( WikiPage page, String name, int version ) throws ProviderException
    {
        Connection connection = null;
        try
        {
            connection = getConnection();
            String sql = "SELECT ATT_LENGTH," +
                    " ATT_MODIFIED, ATT_MODIFIED_BY, ATT_VERSION" +
                    " FROM " + ATT_TABLE_NAME +
                    " WHERE ATT_PAGENAME = ?" +
                    "    AND ATT_FILENAME = ?" +
                    "    AND ATT_VERSION = ?" +
                    " GROUP BY ATT_FILENAME" +
                    " ORDER BY ATT_VERSION DESC";   // so latest version is first
            PreparedStatement ps = connection.prepareStatement( sql );
            ps.setString( 1, page.getName() );
            ps.setString( 2, name );
            ps.setInt( 3, version );
            ResultSet rs = ps.executeQuery();

            Attachment att = null;
            if( rs.next() )
            {
                att = new Attachment( getEngine(), page.getName(), name );
                att.setSize( rs.getInt( "ATT_LENGTH" ) );
                // use Java Date for friendlier comparisons with other dates
                att.setLastModified(new java.util.Date(rs.getTimestamp("ATT_MODIFIED").getTime()));
                att.setAuthor( rs.getString( "ATT_MODIFIED_BY" ) );
                att.setVersion( rs.getInt( "ATT_VERSION" ) );
            }
            else
            {
                debug( "No attachment info for " + page + "/" + name + ":" + version );
            }
            rs.close();
            ps.close();
            return att;
        }
        catch( SQLException se )
        {
            error( "Unable to get attachment info for " + page + "/" + name + ":" + version, se );
            return null;
        }
        finally
        {
            releaseConnection( connection );
        }
    }

    /**
     * Goes through the repository and decides which version is
     * the newest one in that directory.
     * 
     * @return Latest version number in the repository, or 0, if
     *         there is no page in the repository.
     */
    private int findLatestVersion( Attachment att )
    {
        int version = 0;
        Connection connection = null;
        try
        {
            connection = getConnection();
            String sql = "SELECT max(ATT_VERSION)" +
                    " FROM " + ATT_TABLE_NAME +
                    " WHERE ATT_PAGENAME = ?" +
                    "   AND ATT_FILENAME = ?";
            PreparedStatement ps = connection.prepareStatement( sql );
            ps.setString( 1, att.getParentName() );
            ps.setString( 2, att.getFileName() );
            ResultSet rs = ps.executeQuery();

            if( rs.next() )
                version = rs.getInt( 1 );
            rs.close();
            ps.close();

        }
        catch( SQLException se )
        {
            error( "Error trying to find latest attachment: " + att, se );
        }
        finally
        {
            releaseConnection( connection );
        }
        return version;
    }

    public List getVersionHistory( Attachment att )
    {
        List list = new ArrayList();
        Connection connection = null;
        try
        {
            connection = getConnection();
            String sql = "SELECT ATT_LENGTH," +
                    " ATT_MODIFIED, ATT_MODIFIED_BY, ATT_VERSION" +
                    " FROM " + ATT_TABLE_NAME +
                    " WHERE ATT_PAGENAME = ?" +
                    "   AND ATT_FILENAME = ?" +
                    " ORDER BY ATT_VERSION DESC";   // so latest version is first
            PreparedStatement ps = connection.prepareStatement( sql );
            ps.setString( 1, att.getParentName() );
            ps.setString( 2, att.getFileName() );
            ResultSet rs = ps.executeQuery();

            while( rs.next() )
            {
                Attachment vAtt = new Attachment( getEngine(), att.getParentName(), att.getFileName() );
                vAtt.setSize( rs.getInt( "ATT_LENGTH" ) );
                // use Java Date for friendlier comparisons with other dates
                vAtt.setLastModified(new java.util.Date(rs.getTimestamp("ATT_MODIFIED").getTime()));
                vAtt.setAuthor( rs.getString( "ATT_MODIFIED_BY" ) );
                vAtt.setVersion( rs.getInt( "ATT_VERSION" ) );
                list.add( vAtt );
            }
            rs.close();
            ps.close();

        }
        catch( SQLException se )
        {
            error( "Unable to list attachment version history for " + att, se );
        }
        finally
        {
            releaseConnection( connection );
        }
        return list;
    }

    public void deleteVersion( Attachment att ) throws ProviderException
    {
        Connection connection = null;
        try
        {
            connection = getConnection();
            String sql = "DELETE FROM " + ATT_TABLE_NAME +
                    " WHERE ATT_PAGENAME = ?" +
                    "   AND ATT_FILENAME = ?" +
                    "   AND ATT_VERSION = ?";
            PreparedStatement ps = connection.prepareStatement( sql );
            ps.setString( 1, att.getParentName() );
            ps.setString( 2, att.getFileName() );
            ps.setInt( 3, att.getVersion() );
            ps.execute();
            ps.close();
        }
        catch( SQLException se )
        {
            error( "Delete attachment version failed " + att, se );
        }
        finally
        {
            releaseConnection( connection );
        }
    }

    public void deleteAttachment( Attachment att ) throws ProviderException
    {
        Connection connection = null;
        try
        {
            connection = getConnection();
            String sql = "DELETE FROM " + ATT_TABLE_NAME +
                    " WHERE ATT_PAGENAME = ?" +
                    "   AND ATT_FILENAME = ?";
            PreparedStatement ps = connection.prepareStatement( sql );
            ps.setString( 1, att.getParentName() );
            ps.setString( 2, att.getFileName() );
            ps.execute();
            ps.close();
        }
        catch( SQLException se )
        {
            error( "Delete attachment failed " + att, se );
        }
        finally
        {
            releaseConnection( connection );
        }
    }

    /**
     * Move all the attachments for a given page so that they are attached to a
     * new page.
     *
     * @param oldParent Name of the page we are to move the attachments from.
     * @param newParent Name of the page we are to move the attachments to.
     * @throws com.ecyrd.jspwiki.providers.ProviderException
     *          If the attachments could not be moved for some
     *          reason.
     */
    public void moveAttachmentsForPage(String oldParent, String newParent) throws ProviderException {
        Connection connection = null;
        try {
            connection = getConnection();
            String sql = "UPDATE " + ATT_TABLE_NAME +
                         "  SET ATT_PAGE_NAME = ?" +
                         " WHERE ATT_PAGE_NAME = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, oldParent);
            ps.setString(2, newParent);
            ps.execute();
            ps.close();
        }
        catch (SQLException se) {
            String message = "Moving attachment '" + oldParent + "' to '" + newParent + "' failed";
            error(message, se);
            throw new ProviderException(message + ": " + se.getMessage());
        }
        finally {
            releaseConnection(connection);
        }
    }

    /**
     * Copies pages from one provider to this provider.  The source,
     * "import" provider is specified by the properties file at
     * the given path.
     */
    private void migratePages( WikiEngine engine, String path )
            throws IOException
    {
        Properties importProps = new Properties();
        importProps.load( new FileInputStream( path ) );
        String classname = importProps.getProperty( AttachmentManager.PROP_PROVIDER );

        WikiAttachmentProvider importProvider;
        try
        {
            Class providerclass = ClassUtil.findClass( "com.ecyrd.jspwiki.providers",
                    classname );
            importProvider = ( WikiAttachmentProvider ) providerclass.newInstance();
        }
        catch( Exception e )
        {
            error( "Unable to locate/instantiate import provider class " + classname, e );
            return;
        }
        try
        {
            importProvider.initialize( engine, importProps );
            m_migrating = true;
            List attachments = importProvider.listAllChanged( new Date( 0 ) );
            for( Iterator i = attachments.iterator(); i.hasNext(); )
            {
                Attachment att = ( Attachment ) i.next();
                info("Migrating Attachment: "+att.getName()+"("+att.getVersion()+")");
                InputStream data = importProvider.getAttachmentData( att );
                putAttachmentData( att, data );
            }
        }
        catch( ProviderException e )
        {
            throw new IOException( e.getMessage() );
        }
        catch( NoRequiredPropertyException e )
        {
            throw new IOException( e.getMessage() );
        } finally {
            m_migrating = false;
        }
    }

}

